function [OEW] = Compute_OEW_III(W_TO, S_ref, S_HT, S_VT, S_wet, T0)
%COMPUTE_OEW Summary of this function goes here
%   Detailed explanation goes here
% Ref area should be EXPOSED planform area!
% W_Wing = WingDensity * S_ref; % Replace with new wing weight model (accepts arguments of AR and e and other stuff)
% N_z = 9.0; % Ultimate load factor
% tc_root = 0.4; % Thickness-to-chord ratio, root
% Lambda_qc = 0.2275; % taper ratio of quarter chord
% S_csw = 150; % Surface area of control surfaces (FIGURE THIS OUT <<<<<<<<<<<<<<<<<<<<<)

% Density for exposed surface area (fighter)
WingDensity = 9; % lb/ft^2
HTDensity = 4; % lb/ft^2
VTDensity = 5.3; % lb/ft^2
FuselageDensity = 4.8; % lb/ft^2

% W_Wing = wing_weight_IV(W_TO, N_z, S_ref, AR, tc_root, lambda, Lambda_qc, S_csw); % Fidelity level IV only
% W_Wing = WingDensity * S_ref; % Fidelity level III
W_Wing = wing_weight_III(WingDensity, S_ref);
W_HT = wing_weight_III(HTDensity, S_HT);
W_VT = wing_weight_III(VTDensity, S_VT);
W_fuselage = wing_weight_III(FuselageDensity, S_wet); % Fidelity III
W_engine_installed = 1.3*Engine_Sizing(T0);
W_landinggear = 0.033*W_TO;
W_all_else_empty = 0.17*W_TO;

OEW = W_Wing + W_HT + W_VT + W_fuselage + W_engine_installed + W_landinggear; % sum the weights
end